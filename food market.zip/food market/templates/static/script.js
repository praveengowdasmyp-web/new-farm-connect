function viewProducts(farmerId) {
  fetch(`/get_products/${farmerId}`)
    .then(res => res.json())
    .then(products => {
      const div = document.getElementById(`products-${farmerId}`);
      div.innerHTML = "<h4>Products:</h4>";
      products.forEach(p => {
        div.innerHTML += `<p>${p.name} - ₹${p.price}</p>`;
      });
    });
}
