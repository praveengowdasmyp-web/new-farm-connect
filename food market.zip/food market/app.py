from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
from pathlib import Path

app = Flask(__name__)

# Database setup
DB_PATH = Path("database.db")

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        # Farmers table
        c.execute("""
            CREATE TABLE IF NOT EXISTS farmers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                location TEXT,
                contact TEXT
            )
        """)
        # Products table
        c.execute("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                farmer_id INTEGER,
                name TEXT,
                price REAL,
                FOREIGN KEY(farmer_id) REFERENCES farmers(id)
            )
        """)
        # Messages table
        c.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender TEXT,
                receiver TEXT,
                message TEXT
            )
        """)
        # Reviews table
        c.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                farmer_id INTEGER,
                buyer TEXT,
                rating INTEGER,
                comment TEXT,
                FOREIGN KEY(farmer_id) REFERENCES farmers(id)
            )
        """)
        conn.commit()

# Initialize DB on first run
init_db()


# 🏠 Home route
@app.route('/')
def home():
    return render_template('index.html')


# 👨‍🌾 Farmer dashboard
@app.route('/farmer_dashboard')
def farmer_dashboard():
    return render_template('farmer_dashboard.html')


# 🛒 Buyer dashboard
@app.route('/buyer_dashboard')
def buyer_dashboard():
    return render_template('buyer_dashboard.html')


# 💬 Messages page
@app.route('/messages')
def messages():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT sender, receiver, message FROM messages ORDER BY id DESC")
        messages = c.fetchall()
    return render_template('messages.html', messages=messages)


# 📨 Send message (from buyer)
@app.route('/send_message', methods=['POST'])
def send_message():
    sender = request.form['sender']
    receiver = request.form['receiver']
    message = request.form['message']
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("INSERT INTO messages (sender, receiver, message) VALUES (?, ?, ?)", 
                  (sender, receiver, message))
        conn.commit()
    return redirect(url_for('messages'))


# ➕ Add product (from farmer)
@app.route('/add_product', methods=['POST'])
def add_product():
    farmer_id = request.form['farmer_id']
    name = request.form['name']
    price = request.form['price']
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("INSERT INTO products (farmer_id, name, price) VALUES (?, ?, ?)", 
                  (farmer_id, name, price))
        conn.commit()
    return redirect(url_for('farmer_dashboard'))


# ⭐ Add review (from buyer)
@app.route('/add_review', methods=['POST'])
def add_review():
    farmer_id = request.form['farmer_id']
    buyer = request.form['buyer']
    rating = request.form['rating']
    comment = request.form['comment']
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("INSERT INTO reviews (farmer_id, buyer, rating, comment) VALUES (?, ?, ?, ?)",
                  (farmer_id, buyer, rating, comment))
        conn.commit()
    return redirect(url_for('buyer_dashboard'))


# 🌾 API to fetch farmers (for search)
@app.route('/api/farmers')
def get_farmers():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT id, name, location, contact FROM farmers")
        farmers = [dict(id=row[0], name=row[1], location=row[2], contact=row[3]) for row in c.fetchall()]
    return jsonify(farmers)


# 🚀 Run server
if __name__ == '__main__':
    app.run(debug=True)
